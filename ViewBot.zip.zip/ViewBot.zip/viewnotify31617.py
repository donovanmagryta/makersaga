#!/usr/bin/python

#- * -coding: utf - 8 - * -

from pyfiglet import Figlet
f = Figlet(font = 'roman')#or 'roman' font
makersaga = (f.renderText('www.makersa.ga\n'))
from colorama import init, Fore, Back, Style
init(autoreset = True)
print(Back.RED + Fore.YELLOW + Style.BRIGHT + makersaga)# print("www.makersa.ga.\n")
messageappend = input('What is the title of the instructables tutorial you want to monitor?\n')
print("ok \n")
idlink = input("What is the STATS JSON URL from your instructables tutorial? \n")
print('ok \n')
rate = input("At a minimum, how many views must occur between each notification? Enter a number between 1 and 1000 without commas! \n")
print('Setup complete.\n')
print('Scanning for view increases now...\n')

while True:
    import requests
    r = requests.get(idlink)
    jsonstring1 = r.json()
    viewz = jsonstring1['views']
    oldviews = int(viewz)
    oldviewsstr = str(oldviews)
    #while True:
    import time
    time.sleep(20)
    import requests
    r2 = requests.get(idlink)
    jsonstring2 = r2.json()
    viewz2 = jsonstring2['views']
    currentviews = int(viewz2)
    currentviewsstr = str(currentviews)
    sayit = currentviews - oldviews
    sayit2 = str(sayit)
    from num2words import num2words
    sayit3 = num2words(sayit)
    #time.sleep(30)
    interval = int(rate)
    if sayit >= interval:
        print(chr(7))# NOT FOR LINUX
        print(chr(7))# NOT FOR LINUX
        speek = ('plus' + sayit3 + ' views!')
        speek2 =('+' + sayit2 + '\n views!\n')
        bignotify = (f.renderText(speek2))
        print(Back.RED + Fore.YELLOW + Style.BRIGHT + bignotify)
        from gtts import gTTS
        import os
        x = ['jim', 'john', 'josh']
        tts = 'tts'
        for i in range(0, 3):
            tts = gTTS(text = speek, lang = 'en')
            file1 = str('hello' + str(i) + '.mp3')
            tts.save(file1)
        from sys import platform
        if platform == "linux" or platform == "linux2":
            os.system("mpg321 file1 -quiet")# LINUX# linux
        elif platform == "darwin":
            os.system("open " + file1)# MAC# OS X
        elif platform == "win32":
            os.system('start ' + file1)# PC# Windows...
        time.sleep(10)
        os.remove(file1)
        time.sleep(1)
        print('Scanning for more view increases...\n')
        time.sleep(10)
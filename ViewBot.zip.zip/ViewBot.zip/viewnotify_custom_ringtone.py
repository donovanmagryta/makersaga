﻿#!/usr/bin/python
# -*- coding: utf-8 -*-
print ("For the link to the full tutorial and the files you will need, go to  http:makersa.ga.\n")
messageappend = input("What is the title of the instructables tutorial you want to monitor?\n")
print("ok\n\n\n")
idlink = input("What is the URL from your instructables tutorial? \n Warning! it is not the main link! To get the correct URL, you must use Google Chrome by hitting F12 and reloading the page, then search under the network tab for the word Stats. \n For a how-to, go to makersa.ga.\n\n\n")
print("ok\n")
pathsrc = input("What is the location of your notification tone .wav file?\n Example: 'C:/Users/Donovan/Downloads/bell.wav'\n\n\n")
print("ok\n")
rate = input("At a minimum, how many views must occur between each notification?\n Enter a number between 1 and 1000 without commas!\n\n\n")
print("Setup complete.\n")
print("Scanning for view increases now...\n")

while True:
    import requests
    r= requests.get(idlink)
    jsonstring1 = r.json()
    viewz = jsonstring1['views']
    oldviews = int(viewz)
    oldviewsstr = str(oldviews)
     import time
     time.sleep(20)
     import requests
     r2= requests.get(idlink)
     jsonstring2 = r2.json()
     viewz2 = jsonstring2['views']
     currentviews = int(viewz2)
     currentviewsstr = str(currentviews)
     sayit = currentviews - oldviews
     sayit2 = str(sayit)
     time.sleep(30)
     interval = int(rate)
     if sayit >= interval:
         print (" +" + sayit2 + " views! \n")
         import simpleaudio as sa
         wave_obj = sa.WaveObject.from_wave_file(pathsrc)
         play_obj = wave_obj.play()
         play_obj.wait_done()
         print("sound played")
         time.sleep(1)
         print("Scanning for more view increases...\n")
         time.sleep(10)


			